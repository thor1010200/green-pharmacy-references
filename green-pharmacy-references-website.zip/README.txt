# Green Pharmacy References Website

This is a simple static website containing all 10 poster references.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. In the repository, open Settings → Pages.
4. Select deployment from the `main` branch and `/ (root)`.
5. GitHub will provide a public website URL.
6. Use that public URL to make the final QR code.

Important: the QR code should point to the final public GitHub Pages URL, not to the local HTML file.
